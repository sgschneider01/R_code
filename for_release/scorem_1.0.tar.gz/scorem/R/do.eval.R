do.eval <-
function (x) {
  eval(parse(text=x)) 
}

